from recipe_scrapers import scrape_me

scraper = scrape_me('https://iwashyoudry.com/garlic-parmesan-pork-chop-recipe/',wild_mode=True)

title = scraper.title()
totaltime = scraper.total_time()
yeild=scraper.yields()
ing = scraper.ingredients()
inst=scraper.instructions()
img = scraper.image()
scraper.host()
scraper.links()
nutrients=scraper.nutrients() 
print(img)
print(ing)
print(inst)
print(yeild)
print(nutrients)
